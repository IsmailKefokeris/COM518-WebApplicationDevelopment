const express = require('express');
const app = express();
const mysql = require('mysql2');


// change this as appropriate if you want to test
const conn = mysql.createConnection({
    host:'localhost',
    user: 'root',
    database:'mysql'
});

// Q14 you need to add the full code to use session variables to enable a login system.

conn.connect( err => {
  if(err) {
    console.log('Could not connect to database server');
    process.exit(1);
  } else {

    
    
    // Q4 complete the route to find all events of the user's chosen type
    app.get('/search/:eType', (req, res) => {
        conn.query('SELECT * FROM ?????",
            [ ????? ], 
            (err, results, fields) => {
                // Q5 complete to return the details as JSON 
            });
    });

    // Q7 complete the route to allow user to book the event 
    app.post('/book/:eventid', (req, res) => {
        conn.query("UPDATE ?????",
            [ ????? ],
            (err, results, fields) => {
                if(err) {
                    res.status(500).json({'error': 'Internal error'});
                } else {
                    res.json({'success': 1});
                }
            });
    });

 
    app.post('/signup', (req, res) => {
        // Q11 send back an error if the two password fields are unequal (you need to add this code...)

        // Q10 complete the 'signup' route as described in the paper
        conn.query("INSERT INTO ?????",
            [ ????? ],
            (err, results, fields) => {
                if(err) {
                    res.status(500).json({'error': 'Internal error'});
                } else {
                    res.json({'success': 1});
                }
            });
    });

    app.listen(3000);
  }
});
