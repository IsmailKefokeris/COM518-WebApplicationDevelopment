USE ephp001; -- change mysql to your database name

CREATE TABLE IF NOT EXISTS welders_users
(ID INT PRIMARY KEY AUTO_INCREMENT,
username VARCHAR(255),
password VARCHAR(255));

CREATE TABLE IF NOT EXISTS events 
(ID INT PRIMARY KEY AUTO_INCREMENT,
eventname VARCHAR(255),
eventtype VARCHAR(255),
eventdate VARCHAR(255),
eventprice FLOAT,
ntickets INT DEFAULT 100);

INSERT INTO welders_users(username,password)
VALUES 
('root', 'root123'),
('tim', 'tim123'),
('kate', 'kate123');

INSERT INTO events(eventname,eventtype,eventdate,eventprice)
VALUES
('Postmodern Doom', 'band', '010522', 15),
('Metagalactic Hamstaaz', 'band', '020522', 20),
('The Wall', 'band', '030522', 10),
('80s Night', 'club', '040522', 5);
