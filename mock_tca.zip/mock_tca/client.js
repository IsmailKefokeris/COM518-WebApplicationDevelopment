
// Q1 replace the ????? so that this event listener handles click events on
// the event search button
document.getElementById('?????').addEventListener('click', () => {

    // Q2 complete this statement to read the event type from the form
    const type = ?????;

    // Q3 complete the fetch API call to send the user's chosen event type
    // to the 'event search' route in server.js. You will need to look
    // at the server.js code to complete this successfully.
    fetch('?????').then (response => response.json())
        .then(json => {
        // Q6 complete so that it parses the JSON returned and outputs the
        // data to the searchresults <div> in a readable HTML format.

        // Q8 update with a book button - see question paper
        
    });    

});

// Q9 replace the ????? so that this event listener handles click events on
// the signup button
// Note the event listener has been setup to be an async function - this may help you
document.getElementById('?????').addEventListener('click', async() => {

    // Q9 complete these statements to read user details from the form
    const theUser = ?????;
    const thePass = ?????;
    const thePass2 = ?????;

    // Q9 complete the fetch API call to send the data to the 'signup'
    // route on the server as a POST request... 

    // Q12 modify Q9 answer to handle non-200 status codes. Ensure that
    // user-friendly error messages are displayed to the user in the
    // 'signupStatus' <div>.
});
