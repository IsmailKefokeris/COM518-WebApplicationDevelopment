# COM518 Assignment 1 - Develope PlacesToStay Application
Assignment for COM518 Web Application Development.


## Technologies used
Bootstrap
NodeJS
Mysql


## How to Run

- Step 1: Open terminal in directory
- Step 2: Use the following command to install all dependencies - `npm install`
- Step 3(If you are running on goormide):next run the following command to start up the application - `npm run goorm`
- Step 3(If you are running local): next run the following command to start up the application - `npm run dev`